# JARVIS — Como gerar o APK instalável

Este pacote contém o **código-fonte**, ainda não um APK compilado.

## GitHub Actions (não precisa instalar Android Studio)

1. Crie um repositório privado em https://github.com/new.
2. Descompacte o ZIP, e envie todo o **conteúdo da pasta JARVIS-Pronto** para a raiz do repositório, incluindo a pasta oculta `.github/workflows`.
3. Abra **Actions**, habilite workflows se necessário e escolha **Gerar APK de teste da JARVIS** > **Run workflow**.
4. Quando a execução concluir com sucesso, baixe o artefato **JARVIS-debug-APK**.
5. Extraia o arquivo do artefato para obter **app-debug.apk**.
6. No celular Android, abra o APK pelo gerenciador de arquivos e autorize a instalação dessa origem, caso solicitado.

**Observação:** a compilação utiliza recursos do GitHub Actions (podem existir limites de uso).

## Android Studio (computador)

1. Abra a pasta deste projeto no Android Studio (arquivo `settings.gradle`).
2. Instale SDK Android API 35 e ferramentas de compilação, e configure Gradle 8.11.1. Este projeto não inclui `gradle-wrapper.jar`.
3. No menu **Build**, selecione **Build APK(s)**.
4. APK em `app/build/outputs/apk/debug/app-debug.apk`.

## Testes após instalar

Autorize microfone. Teste: `Jarvis, bom dia`, `Abra o WhatsApp`, `Pesquise sobre Recife`, `Acenda a lanterna`, `Ligue para Maria`.

## Verificações deste pacote

Sintaxe dos XML e do AndroidManifest: verificada. Interpretador `CommandRouter.kt`: compilado e testado em Kotlin/JVM. **O APK completo não foi compilado** neste ambiente porque o Android SDK e o Gradle não estão presentes, e a rede não permitiu baixar essas ferramentas.
