package br.com.jarvis.mobile

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.KeyEvent
import android.view.View
import android.view.WindowInsets
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * JARVIS Android v0.1: comandos locais + serviços padrão Android.
 * Não usa API paga de IA, não capta áudio em segundo plano e não faz ligações
 * sem confirmação. Pesquisas comuns abrem o navegador; explicações breves
 * consultam a API pública da Wikipédia em HTTPS.
 */
class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var conversation: TextView
    private lateinit var entry: EditText
    private lateinit var micButton: ImageButton

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var torchEnabled = false
    private var pendingContact: String? = null
    private var pendingPhone: String? = null
    private var pendingTorch: Boolean? = null

    private val locale = Locale("pt", "BR")

    companion object {
        const val REQUEST_AUDIO = 101
        const val REQUEST_CONTACTS = 102
        const val REQUEST_CALL = 103
        const val REQUEST_CAMERA = 104
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.txtStatus)
        conversation = findViewById(R.id.txtConversation)
        entry = findViewById(R.id.editCommand)
        micButton = findViewById(R.id.btnMic)

        // Reserva espaço para as barras do sistema no Android 15+.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val root = findViewById<View>(R.id.root)
            val start = root.paddingLeft
            val top = root.paddingTop
            val end = root.paddingRight
            val bottom = root.paddingBottom
            root.setOnApplyWindowInsetsListener { view, insets ->
                val system = insets.getInsets(WindowInsets.Type.systemBars())
                view.setPadding(start + system.left, top + system.top, end + system.right, bottom + system.bottom)
                insets
            }
            root.requestApplyInsets()
        }

        tts = TextToSpeech(this) { code ->
            if (code == TextToSpeech.SUCCESS) {
                runOnUiThread {
                    val result = tts?.setLanguage(locale) ?: TextToSpeech.LANG_NOT_SUPPORTED
                    ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                        result != TextToSpeech.LANG_NOT_SUPPORTED
                    if (!ttsReady) status.text = "Instale a voz Português (Brasil) no Android."
                }
            }
        }

        micButton.setOnClickListener { listen() }
        findViewById<Button>(R.id.btnSearch).setOnClickListener { promptCommand("pesquise sobre ") }
        findViewById<Button>(R.id.btnCall).setOnClickListener { promptCommand("ligue para ") }
        findViewById<Button>(R.id.btnTorch).setOnClickListener { interpret("lanterna") }
        findViewById<Button>(R.id.btnHelp).setOnClickListener { interpret("ajuda") }
        findViewById<Button>(R.id.btnSend).setOnClickListener { submitTyped() }
        entry.setOnEditorActionListener { _, _, event ->
            if (event == null || event.keyCode == KeyEvent.KEYCODE_ENTER) {
                submitTyped()
                true
            } else false
        }
    }

    private fun promptCommand(prefix: String) {
        entry.setText(prefix)
        entry.setSelection(entry.text.length)
        entry.requestFocus()
        getSystemService(InputMethodManager::class.java).showSoftInput(entry, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun submitTyped() {
        val command = entry.text.toString().trim()
        if (command.isEmpty()) return
        entry.text.clear()
        getSystemService(InputMethodManager::class.java).hideSoftInputFromWindow(entry.windowToken, 0)
        interpret(command)
    }

    private fun listen() {
        if (listening) {
            recognizer?.stopListening()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_AUDIO)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            respond("O serviço de reconhecimento de voz não está disponível neste aparelho. Use os comandos escritos ou instale um serviço de reconhecimento de fala.")
            return
        }
        try {
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                    setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {
                            status.text = "Estou ouvindo..."
                        }
                        override fun onBeginningOfSpeech() { status.text = "Pode falar." }
                        override fun onRmsChanged(rmsdB: Float) = Unit
                        override fun onBufferReceived(buffer: ByteArray?) = Unit
                        override fun onEndOfSpeech() { status.text = "Processando sua voz..." }
                        override fun onError(error: Int) {
                            listening = false
                            micButton.alpha = 1f
                            status.text = when (error) {
                                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                                    "Não entendi. Toque no microfone e tente novamente."
                                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                                    "Falha na rede do serviço de voz. Tente digitar."
                                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                                    "Permita o uso do microfone nas configurações."
                                else -> "Não consegui reconhecer a fala (erro $error)."
                            }
                        }
                        override fun onResults(results: Bundle?) {
                            listening = false
                            micButton.alpha = 1f
                            status.text = "Pronto para outro comando"
                            val phrases = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val first = phrases?.firstOrNull()
                            if (!first.isNullOrBlank()) interpret(first)
                            else status.text = "Nenhuma frase reconhecida."
                        }
                        override fun onPartialResults(partialResults: Bundle?) = Unit
                        override fun onEvent(eventType: Int, params: Bundle?) = Unit
                    })
                }
            }
            tts?.stop()
            listening = true
            micButton.alpha = 0.65f
            status.text = "Iniciando microfone..."
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-BR")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            listening = false
            micButton.alpha = 1f
            status.text = "Não foi possível iniciar o microfone: ${e.localizedMessage ?: "erro"}"
        }
    }

    private fun interpret(raw: String) {
        appendMessage("VOCÊ", raw)
        when (val command = CommandRouter.parse(raw)) {
            is Command.Hello -> respond("Olá! Sou a JARVIS. Posso pesquisar, consultar a Wikipédia, ligar para contatos, abrir aplicativos e acender a lanterna.")
            is Command.Help -> respond(
                "Experimente: ligue para Maria; pesquise sobre tecnologia; quem é Ada Lovelace; " +
                "abra WhatsApp; acenda a lanterna; desligue a lanterna; que horas são; onde fica Recife.",
                spoken = "Você pode pedir pesquisas, ligações, aplicativos, lanterna, horários e informações da Wikipédia."
            )
            is Command.Time -> respond("Agora são ${SimpleDateFormat("HH:mm", locale).format(Date())}.")
            is Command.Date -> respond("Hoje é ${DateFormat.getDateInstance(DateFormat.FULL, locale).format(Date())}.")
            is Command.Search -> searchBrowser(command.terms)
            is Command.Explain -> searchWikipedia(command.topic)
            is Command.Call -> callTarget(command.target)
            is Command.Open -> openApp(command.name)
            is Command.Maps -> openUrl("https://www.google.com/maps/search/?api=1&query=${Uri.encode(command.place)}", "Abrindo mapa de ${command.place}.")
            is Command.Torch -> switchTorch(command.enabled)
            is Command.Unknown -> respond("Ainda não tenho esse comando. Diga 'ajuda' para conhecer as funções disponíveis. Esta versão não usa IA conversacional paga.")
        }
    }

    private fun respond(message: String, spoken: String = message) {
        appendMessage("JARVIS", message)
        if (ttsReady) tts?.speak(spoken.take(650), TextToSpeech.QUEUE_FLUSH, null, "jarvis-${System.nanoTime()}")
    }

    private fun appendMessage(who: String, message: String) {
        val before = conversation.text.toString()
        val content = "$before\n\n$who\n$message"
        // Evita manter um histórico ilimitado na memória.
        conversation.text = if (content.length > 5000) content.takeLast(5000) else content
    }

    private fun openUrl(url: String, message: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            respond(message)
        } catch (_: ActivityNotFoundException) {
            respond("Não encontrei um aplicativo para abrir este endereço.")
        } catch (_: SecurityException) {
            respond("O Android bloqueou a abertura deste endereço.")
        }
    }

    private fun searchBrowser(terms: String) {
        openUrl("https://www.google.com/search?q=${Uri.encode(terms)}", "Pesquisando por $terms no navegador.")
    }

    private fun searchWikipedia(topic: String) {
        respond("Consultando a Wikipédia sobre $topic.")
        Thread {
            var result: String? = null
            try {
                val encoded = java.net.URLEncoder.encode(topic, "UTF-8")
                val url = URL("https://pt.wikipedia.org/w/api.php?action=query&format=json&formatversion=2&prop=extracts&exintro=1&explaintext=1&redirects=1&titles=$encoded")
                val connection = url.openConnection() as HttpURLConnection
                try {
                    connection.requestMethod = "GET"
                    connection.connectTimeout = 7000
                    connection.readTimeout = 7000
                    connection.setRequestProperty("Accept", "application/json")
                    connection.setRequestProperty("User-Agent", "JarvisMobile/0.1 (Android; educational assistant)")
                    if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                        val json = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                        val pages = JSONObject(json).optJSONObject("query")?.optJSONArray("pages")
                        result = pages?.optJSONObject(0)?.optString("extract")?.trim()
                    }
                } finally { connection.disconnect() }
            } catch (_: Exception) { /* A pesquisa convencional continuará disponível. */ }
            val extract = result
            Handler(Looper.getMainLooper()).post {
                if (isFinishing || isDestroyed) return@post
                if (extract.isNullOrBlank()) {
                    searchBrowser(topic)
                } else {
                    val summary = extract.replace(Regex("\\s+"), " ").take(580)
                    respond("Wikipédia: $summary${if (extract.length > 580) "…" else ""}")
                }
            }
        }.start()
    }

    private fun openApp(name: String) {
        val key = CommandRouter.normalize(name)
        when {
            "configur" in key || "ajustes" in key -> launchIntent(Intent(Settings.ACTION_SETTINGS), "Abrindo configurações.")
            "camera" in key -> launchIntent(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA), "Abrindo a câmera.")
            "telefone" in key || "discador" in key -> launchIntent(Intent(Intent.ACTION_DIAL), "Abrindo telefone.")
            "mapa" in key || "maps" in key -> launchPackages(listOf("com.google.android.apps.maps"), "https://maps.google.com", "Abrindo mapas.")
            "whats" in key -> launchPackages(listOf("com.whatsapp"), "https://www.whatsapp.com", "Abrindo WhatsApp.")
            "youtube" in key -> launchPackages(listOf("com.google.android.youtube"), "https://www.youtube.com", "Abrindo YouTube.")
            "chrome" in key || "navegador" in key -> launchPackages(listOf("com.android.chrome"), "https://www.google.com", "Abrindo navegador.")
            "calculadora" in key -> launchPackages(listOf("com.google.android.calculator", "com.android.calculator2", "com.sec.android.app.popupcalculator", "com.miui.calculator", "com.coloros.calculator"), null, "Abrindo calculadora.")
            else -> respond("Ainda não tenho um atalho para $name. Os aplicativos disponíveis incluem WhatsApp, YouTube, Maps, Chrome, câmera, calculadora e configurações.")
        }
    }

    private fun launchPackages(packages: List<String>, fallbackUrl: String?, message: String) {
        for (pkg in packages) {
            val intent = packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                launchIntent(intent, message)
                return
            }
        }
        if (fallbackUrl != null) openUrl(fallbackUrl, "Aplicativo não localizado. Abrindo versão web.")
        else respond("Não encontrei esse aplicativo instalado no celular.")
    }

    private fun launchIntent(intent: Intent, message: String) {
        try {
            startActivity(intent)
            respond(message)
        } catch (_: Exception) { respond("Não consegui abrir esse aplicativo.") }
    }

    private fun callTarget(target: String) {
        if (Regex("^\\+?[0-9()\\s-]{8,}$").matches(target)) {
            val number = target.filter { it.isDigit() || it == '+' }
            confirmCall(target, number)
            return
        }
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            pendingContact = target
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), REQUEST_CONTACTS)
            return
        }
        searchContacts(target)
    }

    private fun searchContacts(name: String) {
        val matches = linkedMapOf<String, String>()
        try {
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
            )?.use { cursor ->
                val nameIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
                val requested = CommandRouter.normalize(name)
                while (cursor.moveToNext() && matches.size < 25) {
                    val displayName = cursor.getString(nameIdx) ?: continue
                    val phone = cursor.getString(numIdx) ?: continue
                    if (CommandRouter.normalize(displayName).contains(requested)) {
                        matches["$displayName • $phone"] = phone
                    }
                }
            }
        } catch (_: SecurityException) {
            respond("Não consegui acessar os contatos. Confira a permissão de contatos.")
            return
        } catch (_: Exception) {
            respond("Não consegui consultar seus contatos.")
            return
        }
        if (matches.isEmpty()) {
            respond("Não encontrei o contato '$name' na agenda.")
            return
        }
        if (matches.size == 1) {
            val match = matches.entries.first()
            confirmCall(match.key, match.value)
        } else {
            val options = matches.keys.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("Qual contato você deseja chamar?")
                .setItems(options) { _, which ->
                    val label = options[which]
                    val number = matches[label] ?: return@setItems
                    confirmCall(label, number)
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }
    }

    private fun confirmCall(contactLabel: String, number: String) {
        AlertDialog.Builder(this)
            .setTitle("Confirmar ligação")
            .setMessage("Deseja ligar para $contactLabel?")
            .setPositiveButton("Ligar") { _, _ -> callNumber(number) }
            .setNegativeButton("Cancelar") { _, _ -> respond("Ligação cancelada.") }
            .show()
    }

    private fun callNumber(number: String) {
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            pendingPhone = number
            requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), REQUEST_CALL)
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_CALL, Uri.fromParts("tel", number, null)))
            respond("Iniciando ligação.")
        } catch (_: SecurityException) {
            openDialer(number)
        } catch (_: ActivityNotFoundException) {
            respond("Não há serviço telefônico disponível neste aparelho.")
        }
    }

    private fun openDialer(number: String) {
        launchIntent(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null)),
            "Abri o discador. Confirme a chamada no aplicativo Telefone.")
    }

    private fun switchTorch(requestedState: Boolean?) {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            pendingTorch = requestedState
            requestPermissions(arrayOf(Manifest.permission.CAMERA), REQUEST_CAMERA)
            return
        }
        try {
            val manager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = manager.cameraIdList.firstOrNull { id ->
                val characteristics = manager.getCameraCharacteristics(id)
                characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    characteristics.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
            if (cameraId == null) {
                respond("Não encontrei uma lanterna compatível neste aparelho.")
                return
            }
            val enabled = requestedState ?: !torchEnabled
            manager.setTorchMode(cameraId, enabled)
            torchEnabled = enabled
            respond(if (enabled) "Lanterna ligada." else "Lanterna desligada.")
        } catch (_: Exception) {
            respond("Não consegui controlar a lanterna. Feche a câmera ou confira as permissões.")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val granted = grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
        when (requestCode) {
            REQUEST_AUDIO -> if (granted) listen() else respond("O microfone não foi autorizado. Os comandos escritos continuam disponíveis.")
            REQUEST_CONTACTS -> {
                val target = pendingContact
                pendingContact = null
                if (granted && target != null) searchContacts(target)
                else respond("Para buscar uma pessoa pelo nome, autorize o acesso aos contatos. Também posso ligar para um número digitado.")
            }
            REQUEST_CALL -> {
                val number = pendingPhone
                pendingPhone = null
                if (number != null) {
                    if (granted) callNumber(number) else openDialer(number)
                }
            }
            REQUEST_CAMERA -> {
                val onOff = pendingTorch
                pendingTorch = null
                if (granted) switchTorch(onOff)
                else respond("A permissão da câmera é necessária para acionar a lanterna neste protótipo.")
            }
        }
    }

    override fun onDestroy() {
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }
}
