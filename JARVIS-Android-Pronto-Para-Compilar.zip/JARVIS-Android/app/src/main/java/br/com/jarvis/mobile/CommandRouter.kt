package br.com.jarvis.mobile

import java.text.Normalizer
import java.util.Locale

/** Interpretador local: não envia comandos a servidores de IA. */
sealed interface Command {
    data object Hello : Command
    data object Help : Command
    data object Time : Command
    data object Date : Command
    data class Search(val terms: String) : Command
    data class Explain(val topic: String) : Command
    data class Call(val target: String) : Command
    data class Open(val name: String) : Command
    data class Maps(val place: String) : Command
    data class Torch(val enabled: Boolean?) : Command
    data object Unknown : Command
}

object CommandRouter {
    fun normalize(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .lowercase(Locale.ROOT)
        .trim()

    fun parse(message: String): Command {
        val clean = message.trim().replaceFirst(Regex("^jarvis[\\s,:;.!?-]*", RegexOption.IGNORE_CASE), "").trim()
        val key = normalize(clean)
        if (key.isBlank()) return Command.Hello
        if (key in setOf("oi", "ola", "bom dia", "boa tarde", "boa noite", "tudo bem")) return Command.Hello
        if (key.contains("ajuda") || key.contains("o que voce faz") || key.contains("comandos")) return Command.Help
        if (key.contains("que horas") || key == "horas" || key == "hora") return Command.Time
        if (key.contains("que dia e hoje") || key.contains("data de hoje") || key == "data") return Command.Date

        if (key.contains("lanterna")) {
            return when {
                key.startsWith("deslig") || key.startsWith("apag") -> Command.Torch(false)
                key.startsWith("lig") || key.startsWith("acend") || key.startsWith("ativ") -> Command.Torch(true)
                else -> Command.Torch(null)
            }
        }

        fun tail(vararg prefixes: String): String? {
            for (prefix in prefixes) {
                if (key.startsWith(prefix)) {
                    // Prefixos foram normalizados. Para o português usual, o deslocamento
                    // em caracteres da versão sem acento é igual ao original.
                    return clean.substring(prefix.length.coerceAtMost(clean.length)).trim(' ', ',', ':', '.', '?', '!')
                        .takeIf { it.isNotBlank() }
                }
            }
            return null
        }

        tail("ligue para ", "ligar para ", "telefone para ", "chame ", "disque ")?.let { return Command.Call(it) }
        tail("pesquise sobre ", "pesquisar sobre ", "pesquise ", "pesquisar ", "procure por ", "procure ", "busque ")?.let { return Command.Search(it) }
        tail("quem e ", "o que e ", "me explique ", "explique ", "quem foi ")?.let { return Command.Explain(it) }
        tail("onde fica ", "rota para ", "mapa de ", "como chegar em ")?.let { return Command.Maps(it) }
        tail("abra o ", "abra a ", "abrir o ", "abrir a ", "abra ", "abrir ", "abre ")?.let { return Command.Open(it) }
        if (key.contains("noticias")) return Command.Search(clean)
        return Command.Unknown
    }
}
