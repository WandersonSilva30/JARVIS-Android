# JARVIS — Assistente pessoal para Android (MVP v0.1)

**Status:** código-fonte de protótipo; o APK depende de compilação e teste em aparelho real.
**Custo da versão 0.1:** nenhuma assinatura de IA ou chave de API. Pesquisa no Google via navegador e resumo simples da Wikipédia via API pública (internet/dados móveis podem ter custo do seu plano). Não é um chatbot com IA generativa.

## O que já está implementado no código

- Interface futurista escura, com detalhes ciano, botão central de microfone, comandos rápidos e campo para digitação.
- Reconhecimento de voz **pt-BR** usando o serviço Android disponível no aparelho, ativado por um **toque** no botão.
- Respostas faladas usando **TextToSpeech** em português (depende do mecanismo de voz instalado).
- Pesquisas no Google pelo navegador, sem chave de API.
- Perguntas "quem é"/"o que é" com resumo introdutório da Wikipédia. Se não houver resultado, abre uma pesquisa no navegador.
- Ligação para números ou contatos pelo nome: solicita autorização de contatos, pergunta qual pessoa quando encontra várias, exibe confirmação da chamada e só então chama a API de telefonia. Se o usuário negar CALL_PHONE, abre o discador para confirmação manual.
- Abrir WhatsApp, YouTube, Chrome, Maps, configurações, câmera, telefone e alguns aplicativos de calculadora.
- Controlar a lanterna (se o dispositivo tiver flash e a câmera estiver disponível).
- Data e hora locais do celular.
- Tratamento básico de erros, permissões solicitadas apenas no momento de uso e liberação dos recursos no encerramento.

## O que NÃO faz nesta versão

- **Não** escuta continuamente a palavra "Jarvis" com a tela apagada ou em segundo plano.
- **Não** funciona como serviço de acessibilidade, nem ignora bloqueio de tela ou permissões de segurança.
- **Não** envia mensagens de WhatsApp automaticamente.
- **Não** resume livremente qualquer página de notícias nem tem raciocínio geral de um modelo de linguagem.
- **Não** controla configurações protegidas (ligar Wi-Fi, dados móveis etc.) sem mecanismos oficiais/permissões adequados.
- **Não** foi validado em hardware Android real neste ambiente de criação.

## Arquitetura

```text
[Microfone / entrada digitada]
             |
             v
[SpeechRecognizer (voz -> texto)]
             |
             v
[CommandRouter: comandos locais]
    |        |        |        |
    |        |        |        +--> CameraManager -> Lanterna
    |        |        +-----------> ContactsContract -> confirmação -> ACTION_CALL/ACTION_DIAL
    |        +--------------------> Intent -> Apps/Google Maps/Google Search
    +-----------------------------> Wikipédia HTTPS -> resposta simples
             |
             v
[TextView de resposta + TextToSpeech]
```

Arquivos principais:

- `app/src/main/java/br/com/jarvis/mobile/CommandRouter.kt`: análise de intenção sem internet.
- `app/src/main/java/br/com/jarvis/mobile/MainActivity.kt`: permissões, ações Android, pesquisas, voz e interface.
- `app/src/main/res/layout/activity_main.xml`: interface principal.
- `app/src/main/AndroidManifest.xml`: configurações e permissões.
- `testes/RouterSmokeTest.kt`: testes simples do interpretador que podem ser executados com Kotlin.
- `.github/workflows/apk-debug.yml`: compilação do APK pelo GitHub Actions.

## Opção A — gerar APK pelo GitHub Actions (sem instalar Android Studio)

1. Entre no **GitHub**, crie um **repositório privado** (recomendado para trabalho em andamento).
2. No computador, **extraia o ZIP** e envie o conteúdo da pasta `JARVIS-Android` para a raiz do repositório, mantendo também a pasta oculta `.github/workflows`.
3. Abra a aba **Actions** do repositório. Se necessário, autorize o uso de workflows.
4. Selecione **Gerar APK de teste da JARVIS** > **Run workflow**.
5. Após a execução bem-sucedida, abra o workflow e baixe o artefato **JARVIS-debug-APK**.
6. Extraia o ZIP do artefato: ele conterá `app-debug.apk`.
7. Envie `app-debug.apk` para o celular e siga as instruções de instalação abaixo.

**Importante:** a execução do GitHub Actions precisa de acesso à internet e dos repositórios Maven/Gradle; pode depender dos limites gratuitos da sua conta no GitHub. O código de compilação foi preparado, mas essa pipeline **não foi executada** neste ambiente.

## Opção B — gerar APK pelo Android Studio no Windows

Pré-requisitos: Android Studio recente, Android SDK **API 35**, Android SDK Build Tools **35.0.0**, JDK **17** (use o JDK embutido do Android Studio se compatível) e **Gradle 8.11.1**. As versões do plugin Android e do Gradle foram escolhidas conforme a tabela de compatibilidade oficial.

1. Extraia `JARVIS-Android.zip` no computador.
2. Abra a pasta `JARVIS-Android` pelo **Android Studio > Open**.
3. Este ZIP **não inclui o arquivo binário `gradle-wrapper.jar`**; caso o Android Studio solicite um Gradle Wrapper, instale o Gradle 8.11.1 a partir de https://gradle.org/releases/ e execute no terminal da pasta:

   ```bash
   gradle wrapper --gradle-version 8.11.1
   ```

   Isso criará o `gradlew`, `gradlew.bat` e o `gradle-wrapper.jar` oficiais. Depois reabra/sincronize o projeto.
4. Aguarde o **Gradle Sync** concluir, instalando as dependências quando solicitado.
5. No menu, escolha **Build > Build Bundle(s) / APK(s) > Build APK(s)** (a redação varia conforme o Android Studio).
6. O arquivo de teste ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Como instalar e testar no celular

1. Transfira `app-debug.apk` para a pasta Downloads do aparelho.
2. Abra o APK com o gerenciador de arquivos e permita **Instalar aplicativos desconhecidos** **somente** para esse gerenciador, se o Android solicitar. Desative novamente a autorização se preferir.
3. Abra **JARVIS** na lista de aplicativos.
4. Toque no microfone. Conceda permissão para gravar áudio, se solicitado.
5. Fale de forma natural. Para ligações pelo nome, conceda a permissão de contatos **somente quando quiser usar a função**. A chamada direta também solicita permissão própria.
6. Para testar sem microfone, digite um comando e toque em **Enviar**.
7. Para respostas faladas, confirme nas Configurações do celular que há uma voz **Texto para fala** em português (Brasil).

Teste nesta ordem, sem risco de discagem involuntária:

```text
Jarvis, bom dia
Que horas são?
Abra o WhatsApp
Pesquise sobre inteligência artificial
Quem é Ada Lovelace?
Acenda a lanterna
Desligue a lanterna
Ligue para [nome de um contato de teste]
```

Para o último comando, o aplicativo precisa solicitar confirmação **antes da ligação**. Toque em "Cancelar" se estiver só testando.

## Permissões e privacidade

| Permissão | Por quê | Quando é pedida |
| --- | --- | --- |
| `RECORD_AUDIO` | reconhecimento da fala | ao tocar no microfone |
| `READ_CONTACTS` | buscar contatos por nome | ao pedir ligação por nome |
| `CALL_PHONE` | iniciar chamada após confirmação | na primeira chamada direta |
| `CAMERA` | acionar a lanterna | ao comandar a lanterna |
| `INTERNET` | consultar resumos da Wikipédia | não requer diálogo de permissão |

O app não tem servidor de IA, não guarda o áudio, não compartilha sua agenda com a Wikipédia e não usa rastreadores ou analytics integrados. O serviço de reconhecimento de voz do sistema Android pode processar a fala **on-line**, conforme as configurações e políticas desse serviço; isso não equivale a garantia de processamento totalmente local. A busca do navegador e a Wikipédia recebem, respectivamente, os termos enviados para pesquisa/consulta. O histórico textual mostrado fica apenas em memória enquanto a tela está aberta.

## Solução de problemas

- **Não reconhece voz:** verifique a permissão do microfone e o serviço de reconhecimento de fala do Android/Google, além da conectividade, se o serviço exigir rede.
- **JARVIS não fala:** configure/instale um mecanismo de texto para fala e uma voz pt-BR.
- **Contato não aparece:** confirme o nome no app Contatos e conceda `READ_CONTACTS`. Se vários resultados forem encontrados, escolha o correto.
- **Ligação não ocorre:** confirme a janela de ligação e a permissão telefônica; o aparelho precisa oferecer telefonia. Se negar `CALL_PHONE`, o discador é aberto.
- **Lanterna não liga:** autorize câmera; encerre outros aplicativos que estejam usando a câmera; alguns dispositivos não disponibilizam lanterna pelo sistema.
- **App não abre aplicativo terceiro:** os nomes/pacotes podem variar entre fabricantes. Adicione o pacote em `openApp` e no `<queries>` do Manifest.
- **Android Studio reclama de Gradle:** verifique a seção 'Opção B'.

## Próximos incrementos recomendados (fora do MVP)

1. Wake-word "Jarvis" local, com indicador transparente de captação e integração oficial do assistente Android onde possível.
2. Serviço como assistente padrão, respeitando bloqueio de tela e as restrições modernas de execução em segundo plano.
3. Sistema de plugins/comandos, gerenciamento das permissões e testes instrumentados.
4. Backend opcional, com autenticação segura e IA generativa, **sem embutir chaves secretas no APK**.
5. Integrações de calendário e lembretes; interface de histórico persistente opt-in.

## Avisos técnicos

- `targetSdk=35`, `compileSdk=35`, `minSdk=26` (Android 8.0 ou superior).
- Kotlin, Views/XML, sem dependências extras de UI e sem assinatura de serviços de IA.
- O projeto precisa de **compilação real** e **teste em aparelho** antes de uso habitual. Não há APK já compilado neste pacote.
- Chamadas telefônicas podem ser tarifadas pela operadora; o app em si é gratuito.


## Guia resumido de compilação

Veja `COMO-GERAR-O-APK.md` para gerar o APK via GitHub Actions ou Android Studio.
