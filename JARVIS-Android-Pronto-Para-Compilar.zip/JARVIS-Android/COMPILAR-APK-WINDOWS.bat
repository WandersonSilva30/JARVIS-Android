@echo off
cd /d "%~dp0"
echo Compilando JARVIS...
where gradle >nul 2>nul
if %errorlevel%==0 (
 gradle --no-daemon :app:assembleDebug
) else (
 if exist gradlew.bat (
  call gradlew.bat --no-daemon :app:assembleDebug
 ) else (
  echo Gradle ausente. Abra o projeto no Android Studio ou utilize GitHub Actions.
  pause
  exit /b 1
 )
)
if %errorlevel% neq 0 (echo ERRO na compilacao. & pause & exit /b 1)
echo APK criado em app\build\outputs\apk\debug\app-debug.apk
pause
