#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if command -v gradle >/dev/null 2>&1; then gradle --no-daemon :app:assembleDebug
elif [ -e ./gradlew ]; then bash ./gradlew --no-daemon :app:assembleDebug
else echo 'Gradle ausente. Utilize Android Studio ou GitHub Actions.' >&2; exit 1; fi
echo 'APK: app/build/outputs/apk/debug/app-debug.apk'
