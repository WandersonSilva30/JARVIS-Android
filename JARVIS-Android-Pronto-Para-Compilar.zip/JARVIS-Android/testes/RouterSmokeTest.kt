import br.com.jarvis.mobile.Command
import br.com.jarvis.mobile.CommandRouter

fun main() {
    fun checkParsed(input: String, expected: Any) {
        val actual = CommandRouter.parse(input)
        check(actual == expected) { "ERRO: '$input': $actual != $expected" }
        println("OK: $input => $actual")
    }
    checkParsed("Jarvis, bom dia", Command.Hello)
    checkParsed("Jarvis ligue para Maria", Command.Call("Maria"))
    checkParsed("Ligue para 81999998888", Command.Call("81999998888"))
    checkParsed("pesquise sobre ciência da computação", Command.Search("ciência da computação"))
    checkParsed("Quem é Ada Lovelace?", Command.Explain("Ada Lovelace"))
    checkParsed("O que é energia solar?", Command.Explain("energia solar"))
    checkParsed("Abra o WhatsApp", Command.Open("WhatsApp"))
    checkParsed("Acenda a lanterna", Command.Torch(true))
    checkParsed("Desligue a lanterna", Command.Torch(false))
    checkParsed("Lanterna", Command.Torch(null))
    checkParsed("Que horas são?", Command.Time)
    checkParsed("Que dia é hoje?", Command.Date)
    checkParsed("onde fica Recife", Command.Maps("Recife"))
    checkParsed("Me mostre a temperatura", Command.Unknown)
}
